import {
    BookstoreServiceProvider,
    BookstoreServiceConsumer
} from './bookstore-service-context';
export {
    BookstoreServiceProvider,
    BookstoreServiceConsumer
};