import Spinner from './spinner';
export default Spinner;